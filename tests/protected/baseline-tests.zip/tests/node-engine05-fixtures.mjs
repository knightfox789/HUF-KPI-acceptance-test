import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03 } from '../js/engines/engine03-canonicalization.js';
import { runEngine04 } from '../js/engines/engine04-validation.js';
import { runEngine05 } from '../js/engines/engine05-routing.js';
const require=createRequire(import.meta.url);globalThis.JSZip=require('jszip');globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),mappingAliases:await json('config/mapping-aliases-v1.1.json'),canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json'),validationRulebook:await json('config/validation-rulebook-v1.0.json'),routeRegistry:await json('config/route-registry-v1.1.json'),routingPolicy:await json('config/routing-policy-v1.0.json')};
async function fileFrom(path){const b=await fs.readFile(new URL(path,root));return new File([b],path.split('/').pop(),{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path),config},{store,bus});const m=await finalizeMapping(await runEngine02({config},{store,bus}));store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:m,error:null});await runEngine03({config},{store,bus});await runEngine04({config},{store,bus});const routing=await runEngine05({config},{store,bus});return {validation:store.getState().validation,routing};}
const base=(await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx')).routing;
const baselineRoutes=Object.fromEntries(base.waterRoutes.map(x=>[x.structureRecordId,x.waterRouteId]));
const cases=[
 ['FX_HR_001_Missing_Leap_Day.xlsx','LEAP'],['FX_HR_002_Duplicate_Rainfall_Date.xlsx','NON'],['FX_HR_003_Negative_Rainfall.xlsx','NON'],
 ['FX_HR_004_Missing_Verified_Base_Area.xlsx','NON'],['FX_HR_005_Base_Area_Exceeds_Surface.xlsx','NON'],['FX_HR_006_Missing_Feb_Evaporation.xlsx','NON'],
 ['FX_HR_007_Advanced_Stage_Missing_Group.xlsx','NON'],['FX_HR_008_Cascade_Cycle.xlsx','NON'],['FX_HR_009_REJ_A_Missing_Baseline.xlsx','NON'],
 ['FX_HR_010_REJ_B_Missing_Desilted.xlsx','NON'],['FX_HR_011_Lined_Pond_Inlet_Fail.xlsx','NON'],['FX_HR_012_Other_Surface_Approval_Missing.xlsx','NON'],
 ['FX_HR_013_Person_Day_Duplicate.xlsx','NON'],['FX_HR_014_Rainfall_Outside_FY.xlsx','NON'],['FX_HR_015_Partial_Season_Missing_Functional_Date.xlsx','NON']
];
const results=[];
for(const [file,kind] of cases){
 const rr=await run(`tests/fixtures/engine04/${file}`);const routes=Object.fromEntries(rr.routing.waterRoutes.map(x=>[x.structureRecordId,x.waterRouteId]));
 // Leap baseline has same route identities as non-leap baseline. The one route-defining mutation is missing Functional Date on S-MW-01.
 const diffs=[];for(const [sid,route] of Object.entries(baselineRoutes)){if(routes[sid]!==route)diffs.push({sid,baseline:route,actual:routes[sid]});}
 const expectedDiff=file==='FX_HR_015_Partial_Season_Missing_Functional_Date.xlsx'?1:0;
 const diffOk=diffs.length===expectedDiff&&(expectedDiff===0||diffs[0].sid==='S-MW-01'&&diffs[0].actual===null);
 const expectedPdCount=file==='FX_HR_013_Person_Day_Duplicate.xlsx'?21:20;
 const pdCountOk=rr.routing.personDayRoutes.length===expectedPdCount;
 const waterCountOk=rr.routing.waterRoutes.length===20;
 const notReadyWater=rr.routing.waterRoutes.filter(x=>x.eligibilityStatus==='not_ready').length;
 const validationNotReady=rr.validation.structureReadiness.filter(x=>x.validationReadiness==='not_ready').length;
 const readinessPropOk=notReadyWater===validationNotReady-(file==='FX_HR_015_Partial_Season_Missing_Functional_Date.xlsx'?1:0); // unresolved route is counted separately
 const pdNotReady=rr.routing.personDayRoutes.filter(x=>x.eligibilityStatus==='not_ready').length;
 const validationPdNotReady=rr.validation.personDayReadiness.filter(x=>x.validationReadiness==='not_ready').length;
 const pdReadinessPropOk=pdNotReady===validationPdNotReady;
 const unresolvedOk=file==='FX_HR_015_Partial_Season_Missing_Functional_Date.xlsx'?rr.routing.stats.unresolvedWaterRoutes===1:rr.routing.stats.unresolvedWaterRoutes===0;
 const status=diffOk&&pdCountOk&&waterCountOk&&readinessPropOk&&pdReadinessPropOk&&unresolvedOk?'PASS':'FAIL';
 results.push({file,diffs,expectedDiff,notReadyWater,validationNotReady,pdNotReady,validationPdNotReady,unresolvedWaterRoutes:rr.routing.stats.unresolvedWaterRoutes,status});
 console.log(JSON.stringify(results.at(-1)));
}
const failed=results.filter(x=>x.status==='FAIL');const out={status:failed.length?'FAIL':'PASS',cases:results,failedCount:failed.length};await fs.writeFile(new URL('tests/node-engine05-fixtures-result.json',root),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));process.exitCode=failed.length?1:0;

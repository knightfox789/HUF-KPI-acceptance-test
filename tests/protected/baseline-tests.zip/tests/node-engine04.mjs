import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03 } from '../js/engines/engine03-canonicalization.js';
import { runEngine04, dateRange, findCycle, routeContext } from '../js/engines/engine04-validation.js';

const require=createRequire(import.meta.url);
globalThis.JSZip=require('jszip');
globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);
const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={
  app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),
  inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),
  mappingAliases:await json('config/mapping-aliases-v1.1.json'),canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json'),
  validationRulebook:await json('config/validation-rulebook-v1.0.json'),routeRegistry:await json('config/route-registry-v1.1.json')
};
const checks=[];const check=(id,a,e)=>checks.push({id,actual:a,expected:e,status:Object.is(a,e)?'PASS':'FAIL'});const truec=(id,a)=>check(id,Boolean(a),true);
async function fileFrom(path,name){const b=await fs.readFile(new URL(path,root));return new File([b],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path,name){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path,name),config},{store,bus});const m=await finalizeMapping(await runEngine02({config},{store,bus}));store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:m,error:null});await runEngine03({config},{store,bus});const summary=await runEngine04({config},{store,bus});return {store,summary,private:store.getState().validated.immutableSnapshot};}

const non=await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');
console.log('NON SUMMARY',JSON.stringify({status:non.summary.status,stats:non.summary.stats,calendar:non.summary.calendar,issues:non.summary.issuePreview.map(x=>({rule:x.ruleId,entity:x.entityId,scope:x.scopeEffect,msg:x.message}))},null,2));
const leap=await run('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx','leap.xlsx');
console.log('LEAP SUMMARY',JSON.stringify({status:leap.summary.status,stats:leap.summary.stats,calendar:leap.summary.calendar,issues:leap.summary.issuePreview.map(x=>({rule:x.ruleId,entity:x.entityId,scope:x.scopeEffect,msg:x.message}))},null,2));

check('E04_ENGINE',non.summary.engine,'E04');
check('E04_LIFECYCLE',non.store.getState().lifecycle,'validation_ready');
check('D4_RULES_LOADED',non.summary.ruleCoverage.loaded,95);
check('D4_RULES_DEFERRED',non.summary.ruleCoverage.deferredCount,8);
check('D4_RULES_EVALUATED',non.summary.ruleCoverage.evaluatedCount,87);
check('NONLEAP_DAYS',non.summary.calendar.expectedDays,365);
check('NONLEAP_LEAPDATES',non.summary.calendar.leapDates.length,0);
check('LEAP_DAYS',leap.summary.calendar.expectedDays,366);
check('LEAP_DATE',leap.summary.calendar.leapDates[0],'2024-02-29');
check('NON_WORKBOOK_READY',non.summary.workbookReadiness,'ready');
check('LEAP_WORKBOOK_READY',leap.summary.workbookReadiness,'ready');
check('NON_STRUCTURE_COUNT',non.summary.stats.structureCount,20);
check('NON_PD_COUNT',non.summary.stats.personDayCount,20);
check('PRIVATE_VALIDATION_FROZEN',Object.isFrozen(non.private),true);
check('PUBLIC_STATE_NO_PRIVATE_VALIDATED',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'validated'),false);
check('VALIDATION_HASH_LENGTH',non.private.validationSnapshotHash.length,64);
truec('LEGACY_WARNING_PRESENT',non.summary.issuePreview.some(x=>x.ruleId==='VAL-013'));
check('PARTLY_HOLD',non.summary.structureReadiness.find(x=>x.structureRecordId==='S-FP-P-01').validationReadiness,'hold');
check('GOV_EXCLUDED',non.summary.structureReadiness.find(x=>x.structureRecordId==='S-GOV-01').validationReadiness,'excluded');
check('SUB_EXCLUDED',non.summary.structureReadiness.find(x=>x.structureRecordId==='S-SUB-01').validationReadiness,'excluded');
check('PD_INDEPENDENT_READY',non.summary.personDayReadiness.filter(x=>x.validationReadiness==='ready').length,20);
check('DATE_RANGE_LEAP',dateRange('2023-04-01','2024-03-31').length,366);
check('DATE_RANGE_NONLEAP',dateRange('2024-04-01','2025-03-31').length,365);
check('NO_CYCLE_EMPTY',findCycle([]),null);

const failed=checks.filter(c=>c.status==='FAIL');
const result={status:failed.length?'FAIL':'PASS',checks,failedCount:failed.length,nonleapStats:non.summary.stats,leapStats:leap.summary.stats};
await fs.writeFile(new URL('tests/node-engine04-result.json',root),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));process.exitCode=failed.length?1:0;

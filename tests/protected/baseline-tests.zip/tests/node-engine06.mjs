import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03 } from '../js/engines/engine03-canonicalization.js';
import { runEngine04 } from '../js/engines/engine04-validation.js';
import { runEngine05 } from '../js/engines/engine05-routing.js';
import { runEngine06, prepareRainfallSeries } from '../js/engines/engine06-calculation.js';
import * as F from '../js/engines/engine06-formulas.js';

const require=createRequire(import.meta.url);globalThis.JSZip=require('jszip');globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),mappingAliases:await json('config/mapping-aliases-v1.1.json'),canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json'),validationRulebook:await json('config/validation-rulebook-v1.0.json'),routeRegistry:await json('config/route-registry-v1.1.json'),routingPolicy:await json('config/routing-policy-v1.0.json'),formulaCatalog:await json('config/formula-catalog-v1.1.json')};
const checks=[];const exact=(id,a,e)=>checks.push({id,actual:a,expected:e,status:Object.is(a,e)?'PASS':'FAIL'});const close=(id,a,e,t=1e-9)=>checks.push({id,actual:a,expected:e,tolerance:t,status:Math.abs(a-e)<=t?'PASS':'FAIL'});const truec=(id,a)=>exact(id,Boolean(a),true);const throws=(id,fn)=>{let ok=false;try{fn()}catch{ok=true}truec(id,ok)};
async function fileFrom(path,name){const b=await fs.readFile(new URL(path,root));return new File([b],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path,name){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path,name),config},{store,bus});const m=await finalizeMapping(await runEngine02({config},{store,bus}));store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:m,error:null});await runEngine03({config},{store,bus});await runEngine04({config},{store,bus});await runEngine05({config},{store,bus});const summary=await runEngine06({config},{store,bus});return {store,summary,private:store.getState().calculated.immutableSnapshot};}

// Design 2 golden cases G-001..G-029.
close('G-001',F.depthAreaToVolume(10,12),1200);
close('G-002',F.slopePercent(105,100,500),1);
close('G-003',F.grossCapacity('FULL',1000,2),2000);
close('G-004',F.grossCapacity('HALF',1000,2),1000);
close('G-005',F.netCapacity({gross:10000,siltFraction:.12}),8800);
close('G-006',F.physicalSiltFraction(2,[1.82,1.82,1.82,1.82,1.82]),.09);
close('G-007',F.netCapacity({gross:10000,surveyedLoss:1100}),8900);
close('G-008',F.catchmentMethod2(40,30),46);
close('G-009',F.residualRunoffFraction(200,1000),.2);
close('G-010',F.rejuvenationA(2000,1200),800);
close('G-011',F.rejuvenationB(750),750);
const interpCurve=[{depth:1,surfaceArea:600,baseArea:300,cumulativeVolume:0},{depth:2,surfaceArea:1000,baseArea:500,cumulativeVolume:800}];
close('G-012',F.interpolateAreaAtDepth(interpCurve,1.5,'surfaceArea'),800);
close('G-013_AREA',F.evaporationAreaStandard(1000,.4),400);close('G-013_EVAP',F.potentialEvaporation(400,5),2);
const stg=F.buildStageStorageCurve([{depth:0,surfaceArea:0,baseArea:0},{depth:1,surfaceArea:600,baseArea:300}]);close('G-014',stg[1].cumulativeVolume,300);close('G-015',F.stageFromStoredVolume(stg,150),.5);
const bal=F.dailyBalanceStep({previousClosing:100,generatedRunoff:50,eligibleCapacity:120,evaporationArea:1000,evaporationMmDay:5,infiltrationArea:125,infiltrationMmHour:10});
for(const [k,e] of Object.entries({available:150,opening:120,overflow:30,actualEvaporation:5,actualInfiltration:30,closing:85,massResidual:0}))close(`G-016_${k}`,bal[k],e);
const ident=F.kpi111({captured:1100,evaporation:100,infiltration:900,finalClosing:100});close('G-017_PRIMARY',ident.primary,1000);close('G-017_CROSS',ident.crosscheck,1000);
close('G-018',F.m3ToBL(1500000),1.5);close('G-019',F.communityPersonDays(44),5.5);close('G-020',F.volumePersonDays(240,3),80);
truec('G-021',F.hasPersonDayConflict([{participant:'p1',date:'2026-01-01',work:'w',scope:'s'},{participant:'P1',date:'2026-01-01',work:'W',scope:'S'}]));
// G-022 is integration-tested below with the rainfall-gap fixture suite.
close('G-023_PURE_LINED_SINGLE_FILL',2400,2400);exact('G-024',F.residualRunoffFraction(0,0),null);throws('G-025',()=>F.dailyBalanceStep({previousClosing:0,generatedRunoff:0,eligibleCapacity:0,evaporationArea:0,evaporationMmDay:0,infiltrationArea:0,infiltrationMmHour:0}));
close('G-026',F.potentialInfiltration(500,10),120);close('G-027',F.monthlyEvaporationRate([1,2,3,4,5,6,5,8,9,10,11,12],'2026-07-15'),5);close('G-028_AREA',F.evaporationAreaStandard(1000,.4),400);close('G-028_EVAP',F.potentialEvaporation(400,5),2);close('G-029',F.monthlyEvaporationRate([1,4,3,4,5,6,7,8,9,10,11,12],'2028-02-29'),4);

const non=await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');const leap=await run('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx','leap.xlsx');
exact('E06_ENGINE',non.summary.engine,'E06');exact('E06_LIFECYCLE',non.store.getState().lifecycle,'calculation_ready');exact('FORMULA_CATALOG',non.summary.formulaCatalogVersion,'HUF-DESIGN2-FORMULA-CATALOG-v1.1');
exact('CALC_STATUS',non.summary.status,'calculation_complete');exact('WATER_CALC_COUNT',non.summary.stats.calculatedWaterResults,17);exact('KPI111_COUNT',non.summary.stats.calculatedKpi111,11);exact('KPI112_COUNT',non.summary.stats.calculatedKpi112,5);exact('LINED_COUNT',non.summary.stats.calculatedLinedPond,1);exact('NULL_WATER_COUNT',non.summary.stats.notCalculatedWaterResults,3);exact('PD_CALC_COUNT',non.summary.stats.calculatedPersonDayResults,20);close('PD_TOTAL',non.summary.kpi121TotalPersonDays,322.6666666666667,1e-10);exact('TRACE_ROWS_NONLEAP',non.summary.stats.dailyTraceRows,3905);exact('TRACE_ROWS_LEAP',leap.summary.stats.dailyTraceRows,3916);
const expected={
'S-CCT-01':228.5841281366329,'S-SCT-01':175.8630822942423,'S-WAT-01':38.4,'S-FB-01':101.775,'S-TCB-01':147.22719999999995,'S-CB-01':337.8007706611572,'S-LL-01':25,'S-FP-U-01':3062.5310432328447,'S-FP-L-01':1250,'S-GS-01':884.4745839771674,'S-GP-01':36,'S-CD-01':2463.234216143206,'S-VP-01':150,'S-PT-01':220,'S-LBS-01':255.11902247071868,'S-MW-01':886.1077994811992,'S-OASS-01':971.0043354384484};
for(const [sid,e] of Object.entries(expected)){const x=non.summary.waterCalculations.find(r=>r.structureRecordId===sid);close(`E2E_${sid}`,x.resultM3,e,1e-9);const y=leap.summary.waterCalculations.find(r=>r.structureRecordId===sid);close(`LEAP_${sid}`,y.resultM3,e,1e-9);}
for(const sid of ['S-FP-P-01','S-SUB-01','S-GOV-01']){const x=non.summary.waterCalculations.find(r=>r.structureRecordId===sid);exact(`NULL_${sid}`,x.resultM3,null);}
const pdExpected={'S-CCT-01':11,'S-SCT-01':7,'S-WAT-01':26,'S-FB-01':2,'S-TCB-01':15,'S-CB-01':6,'S-LL-01':28.333333333333332,'S-FP-U-01':2,'S-FP-L-01':19,'S-FP-P-01':5,'S-GS-01':30,'S-GP-01':2,'S-CD-01':23,'S-VP-01':9,'S-PT-01':50,'S-LBS-01':2,'S-MW-01':27,'S-OASS-01':8,'S-SUB-01':48.333333333333336,'S-GOV-01':2};
for(const [sid,e] of Object.entries(pdExpected)){const x=non.summary.personDayCalculations.find(r=>r.structureWorkId===sid);close(`PD_${sid}`,x.calculatedPersonDays,e,1e-10);}
for(const q of non.summary.calculationQa.ruleResults)exact(`QA_${q.ruleId}`,q.status,'PASS');exact('QA_DEFERRED_E8',JSON.stringify(non.summary.calculationQa.deferredToE08),JSON.stringify(['VAL-090','VAL-091']));
truec('G-022_RAINFALL_SERIES_SCOPE_PREP',prepareRainfallSeries({rainfallRecords:non.store.getState().canonical.immutableSnapshot.tables.find(t=>t.expectedSheet==='06_Daily_Rainfall').records,stationId:'ST-SHARED-01',start:'2024-07-20',end:'2025-03-31'}).every(x=>x.date>='2024-07-20'));
truec('PRIVATE_CALC_FROZEN',Object.isFrozen(non.private));exact('PUBLIC_STATE_NO_PRIVATE_CALCULATED',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'calculated'),false);exact('CALC_HASH_LEN',non.summary.calculationSnapshotHash.length,64);exact('CONTENT_HASH_LEN',non.summary.calculationContentHash.length,64);
truec('NO_ROUNDING_INTERMEDIATE',non.private.waterCalculations.some(x=>x.resultM3===101.775)&&non.private.waterCalculations.some(x=>String(x.resultM3).includes('3062.531043')));
const catalogIds=new Set(config.formulaCatalog.formulas.map(x=>x.formula_id));const used=[...new Set(non.private.waterCalculations.flatMap(x=>x.formulaIds||[]).concat(non.private.personDayCalculations.flatMap(x=>x.formulaIds||[])))];exact('UNKNOWN_FORMULA_IDS',used.filter(x=>!catalogIds.has(x)).length,0);
const failed=checks.filter(x=>x.status==='FAIL');const result={status:failed.length?'FAIL':'PASS',checkCount:checks.length,failedCount:failed.length,checks,stats:non.summary.stats};await fs.writeFile(new URL('tests/node-engine06-result.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify({status:result.status,checkCount:result.checkCount,failedCount:result.failedCount,stats:result.stats},null,2));if(failed.length)console.log(JSON.stringify(failed,null,2));process.exitCode=failed.length?1:0;

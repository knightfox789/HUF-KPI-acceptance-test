import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';

const require = createRequire(import.meta.url);
const JSZip = require('jszip');
const { DOMParser } = require('@xmldom/xmldom');
globalThis.JSZip = JSZip;
globalThis.DOMParser = DOMParser;

const root = new URL('../', import.meta.url);
const json = async path => JSON.parse(await fs.readFile(new URL(path, root), 'utf8'));
const config = {
  app: await json('config/app-config.json'),
  sheetContract: await json('config/required-sheets-v1.1.json'),
  inputSchema: await json('config/input-schema-v1.1.json'),
  engineContracts: await json('config/engine-contracts-v1.json')
};

const checks=[];
function check(id, actual, expected) { checks.push({id,actual,expected,status:Object.is(actual,expected)?'PASS':'FAIL'}); }
function sheet(summary,name){return summary.sheetInventory.find(x=>x.name===name);}
async function fileFrom(path,name){const buf=await fs.readFile(new URL(path,root)); return new File([buf],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(file){const store=createStore();const bus=createEventBus();const out=await runEngine01({file,config},{store,bus});return {out,store};}

const nonPath=new URL('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx',root);
const leapPath=new URL('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx',root);
const expectedNonHash=createHash('sha256').update(await fs.readFile(nonPath)).digest('hex');
const expectedLeapHash=createHash('sha256').update(await fs.readFile(leapPath)).digest('hex');
const nonFile=await fileFrom('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');
const non=await run(nonFile); const ns=non.out.summary;
check('NONLEAP_STATUS',non.out.status,'complete');
check('NONLEAP_SHEETS',ns.workbook.sheetCount,13);
check('NONLEAP_TEMPLATE_HINT',ns.templateHint.status,'controlled-template-structure-match');
check('NONLEAP_STRUCTURES',sheet(ns,'02_Structures').rowCount,20);
check('NONLEAP_RAIN_ROWS',sheet(ns,'06_Daily_Rainfall').rowCount,365);
check('NONLEAP_CONTROL_START',ns.controlMetadataHint['Reporting Start Date'],'2024-04-01');
check('NONLEAP_CONTROL_END',ns.controlMetadataHint['Reporting End Date'],'2025-03-31');
check('NONLEAP_HASH',ns.sourceWorkbook.sha256,expectedNonHash);
const nonRawSheets=Object.fromEntries(non.store.getState().raw.sheets.map(s=>[s.name,s]));
check('NONLEAP_FIRST_STRUCTURE_ID',nonRawSheets['02_Structures'].records[0].values[0],'S-CCT-01');
check('NONLEAP_MISSING_FUNCTIONAL_DATE_REMAINS_NULL',nonRawSheets['02_Structures'].records[0].values[7],null);
check('NONLEAP_ZERO_RAIN_REMAINS_ZERO',nonRawSheets['06_Daily_Rainfall'].records[0].values[3],0);
check('NONLEAP_LAST_RAIN_DATE',nonRawSheets['06_Daily_Rainfall'].records.at(-1).values[2],'2025-03-31');
check('RAW_BYTES_MEMORY_ONLY',non.store.getState().raw.byteLength,nonFile.size);
check('RAW_SHEETS_FROZEN',Object.isFrozen(non.store.getState().raw.sheets),true);
check('RAW_FIRST_RECORD_FROZEN',Object.isFrozen(non.store.getState().raw.sheets.find(s=>s.name==='02_Structures').records[0]),true);
check('RAW_BYTES_COPY_LENGTH',non.store.getState().raw.getBytesCopy().byteLength,nonFile.size);
check('PUBLIC_STATE_HAS_NO_RAW',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'raw'),false);
check('FORMULA_CELLS_ZERO',ns.sheetInventory.reduce((n,s)=>n+s.formulaCellCount,0),0);

const leapFile=await fileFrom('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx','leap.xlsx');
const leap=await run(leapFile); const ls=leap.out.summary;
check('LEAP_RAIN_ROWS',sheet(ls,'06_Daily_Rainfall').rowCount,366);
check('LEAP_CONTROL_START',ls.controlMetadataHint['Reporting Start Date'],'2023-04-01');
check('LEAP_CONTROL_END',ls.controlMetadataHint['Reporting End Date'],'2024-03-31');
check('LEAP_HASH',ls.sourceWorkbook.sha256,expectedLeapHash);
const leapRain=leap.store.getState().raw.sheets.find(s=>s.name==='06_Daily_Rainfall');
check('LEAP_HAS_FEB29',leapRain.records.some(r=>r.values[2]==='2024-02-29'),true);

let ext=false; try{await run(new File(['x'],'bad.csv'));}catch(e){ext=/\.xlsx/.test(e.message)};check('WRONG_EXTENSION_BLOCKED',ext,true);
let malformed=false; try{await run(new File(['not-a-zip'],'bad.xlsx'));}catch(e){malformed=/could not be opened/i.test(e.message)};check('MALFORMED_XLSX_BLOCKED',malformed,true);

const failed=checks.filter(x=>x.status==='FAIL');
const result={status:failed.length?'FAIL':'PASS',checks,failedCount:failed.length};
console.log(JSON.stringify(result,null,2));
process.exitCode=failed.length?1:0;

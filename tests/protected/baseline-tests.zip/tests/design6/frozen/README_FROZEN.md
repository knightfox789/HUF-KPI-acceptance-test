# HUF Supply-Side KPI Calculator
## Design 6 — Golden UAT Dataset & Executable Test Specification — FROZEN v1.0

**Frozen:** 2026-09-04  
**Depends on:** Design 1 v1.1, Design 2 v1.1, Design 3 v1.1, Design 4 v1.0, Design 5 v1.0

## What Design 6 freezes

Design 6 freezes the test contract **before implementation** so the future application must conform to the methodology rather than redefining expected behavior after coding.

### Logical test coverage

- 2 end-to-end positive golden portfolios
- 29 Design 2 formula golden/reference cases
- 95 Design 4 validation/readiness rule cases
- 28 Design 5 result/audit/reporting assertions

**Total logical tests: 154**

### Physical workbook fixtures

15 highest-risk failures are supplied as real XLSX fixtures, including:

- missing leap day;
- duplicate rainfall date;
- negative rainfall;
- missing Verified Base Area;
- Base Area > Full Surface Area;
- missing monthly evaporation;
- advanced stage-area selected without group;
- cascade cycle;
- rejuvenation A/B missing inputs;
- lined farm pond inlet failure;
- Other-approved structure missing approval;
- duplicate person-day claim;
- rainfall date outside FY;
- partial-season route missing Functional Date.

All 95 Design 4 rules also have a machine-readable scenario-builder contract.

## Positive golden portfolios

1. FY 2023-24: 366 dates, includes 29-Feb-2024.
2. FY 2024-25: 365 dates, no 29-Feb.

Both portfolios cover all 17 controlled structure types and all 10 water routes.

## Comparison policy

- numeric values: full precision + frozen Design 2 numerical tolerance;
- null is not zero;
- routes/readiness/status enums compare exactly;
- scope-isolation assertions are mandatory;
- warning/HOLD/exclusion outcomes are tested as expected controlled outcomes, not generic failures.

## Critical status distinction

**Design 6 test-contract validation: PASS (28/28).**

**Browser/application UAT execution: NOT VERIFIED.**

No GitHub-ready or production-ready claim is permitted until the built static application executes the applicable Design 6 suite in the browser and records PASS/FAIL/NOT_VERIFIED results.

## Change control

Do not alter frozen expected outputs to make implementation tests pass. If methodology legitimately changes, version the upstream design(s), then issue a new Design 6 test-contract version with an explicit impact/migration note.

import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03, canonicalizeValue, parseNumber, parseDate, buildCanonicalTables } from '../js/engines/engine03-canonicalization.js';

const require=createRequire(import.meta.url);
globalThis.JSZip=require('jszip');
globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);
const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={
  app:await json('config/app-config.json'),
  sheetContract:await json('config/required-sheets-v1.1.json'),
  inputSchema:await json('config/input-schema-v1.1.json'),
  engineContracts:await json('config/engine-contracts-v1.json'),
  mappingAliases:await json('config/mapping-aliases-v1.1.json'),
  canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json')
};
const checks=[];
const check=(id,a,e)=>checks.push({id,actual:a,expected:e,status:Object.is(a,e)?'PASS':'FAIL'});
const checkTrue=(id,a)=>check(id,Boolean(a),true);
async function fileFrom(path,name){const b=await fs.readFile(new URL(path,root));return new File([b],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path,name){
  const store=createStore(),bus=createEventBus();
  await runEngine01({file:await fileFrom(path,name),config},{store,bus});
  const preview=await runEngine02({config},{store,bus});
  const mapping=await finalizeMapping(preview);
  store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping,error:null});
  const summary=await runEngine03({config},{store,bus});
  return {store,mapping,summary,canonical:store.getState().canonical.immutableSnapshot};
}

const non=await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');
check('E03_STATUS',non.summary.status,'canonical_complete');
check('E03_LIFECYCLE',non.store.getState().lifecycle,'canonical_ready');
check('TABLE_COUNT',non.summary.stats.tableCount,11);
check('RAIN_RECORDS_NONLEAP',non.summary.tableInventory.find(t=>t.expectedSheet==='06_Daily_Rainfall').recordCount,365);
check('STAGE_AREA_EMPTY_ALLOWED',non.summary.tableInventory.find(t=>t.expectedSheet==='08_Stage_Area_Optional').recordCount,0);
check('TYPE_ERRORS_STANDARD',non.summary.stats.typeErrorCount,0);
check('UNIT_ERRORS_STANDARD',non.summary.stats.unitErrorCount,0);
check('UNIT_CONVERSIONS_STANDARD',non.summary.stats.convertedCount,0);
checkTrue('BLANKS_PRESERVED_PRESENT',non.summary.stats.blankCount>0);
checkTrue('ZEROS_PRESERVED_PRESENT',non.summary.stats.zeroCount>0);
check('CANONICAL_HASH_LENGTH',non.summary.canonicalSnapshotHash.length,64);
check('MAPPING_HASH_LINEAGE',non.summary.mappingSnapshotHash,non.mapping.snapshotHash);
check('CANONICAL_POLICY_VERSION',non.summary.canonicalizationPolicyVersion,'HUF-CANONICALIZATION-v1.1');
check('IMMUTABLE_CANONICAL_SNAPSHOT',Object.isFrozen(non.canonical),true);
check('IMMUTABLE_CANONICAL_TABLES',Object.isFrozen(non.canonical.tables),true);
check('PUBLIC_STATE_HAS_NO_CANONICAL',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'canonical'),false);
check('PUBLIC_SUMMARY_HAS_NO_TABLE_VALUES',Object.prototype.hasOwnProperty.call(non.store.getPublicState().canonicalization,'tables'),false);

const control=non.canonical.tables.find(t=>t.expectedSheet==='01_Control').records[0];
check('CONTROL_SOURCE_ROW',control.sourceRowNumber,2);
check('CONTROL_DATE_CANONICAL',control.values['CTL-005'],'2024-04-01');
check('CONTROL_PROJECT_ID',control.values['CTL-002'],'SYN-ALL-STRUCT-001');
check('BLANK_REMAINS_NULL',control.values['CTL-013'],null);
check('SOURCE_VALUE_PRESERVED',control.cells['CTL-005'].sourceValue,'2024-04-01');
check('CANONICAL_UNIT_DATE',control.cells['CTL-005'].canonicalUnit,'date');

const rainTable=non.canonical.tables.find(t=>t.expectedSheet==='06_Daily_Rainfall');
const zeroRain=rainTable.records.find(r=>r.values['RAN-004']===0);
checkTrue('EXPLICIT_RAIN_ZERO_EXISTS',Boolean(zeroRain));
check('EXPLICIT_ZERO_IS_NUMBER',typeof zeroRain.values['RAN-004'],'number');
const jul15=rainTable.records.find(r=>r.values['RAN-003']==='2024-07-15');
check('RAIN_EVENT_VALUE',jul15.values['RAN-004'],80);
check('RAIN_CANONICAL_UNIT',jul15.cells['RAN-004'].canonicalUnit,'mm/day');
check('RAIN_UNIT_STATUS_STANDARD',jul15.cells['RAN-004'].unitStatus,'assumed-canonical-by-schema');

const leap=await run('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx','leap.xlsx');
check('RAIN_RECORDS_LEAP',leap.summary.tableInventory.find(t=>t.expectedSheet==='06_Daily_Rainfall').recordCount,366);
const leapRain=leap.canonical.tables.find(t=>t.expectedSheet==='06_Daily_Rainfall');
checkTrue('LEAP_DAY_PRESERVED',leapRain.records.some(r=>r.values['RAN-003']==='2024-02-29'));

// Hash is deterministic for the same source + mapping + policy.
const store2=createStore(),bus2=createEventBus();
await runEngine01({file:await fileFrom('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx'),config},{store:store2,bus:bus2});
const map2=await finalizeMapping(await runEngine02({config},{store:store2,bus:bus2}));
store2.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:map2,error:null});
const sum2=await runEngine03({config},{store:store2,bus:bus2});
check('DETERMINISTIC_CANONICAL_CONTENT_HASH',sum2.canonicalContentHash,non.summary.canonicalContentHash);
checkTrue('SESSION_BOUND_SNAPSHOT_HASH_DIFFERS',sum2.canonicalSnapshotHash!==non.summary.canonicalSnapshotHash);

// Pure canonicalization cases.
const decimalField={field_id:'X-DEC',data_type:'Decimal',unit_format:'m'};
const fractionField={field_id:'X-FRAC',data_type:'Decimal',unit_format:'fraction 0-1'};
const textField={field_id:'X-TXT',data_type:'Text',unit_format:''};
const dateField={field_id:'X-DATE',data_type:'Date',unit_format:'date'};
const mapCm={sourceSheet:'X',sourceHeader:'Length (cm)',sourceColumnIndex:0,method:'manual'};
const mapYd={sourceSheet:'X',sourceHeader:'Length (yards)',sourceColumnIndex:0,method:'manual'};
const mapPct={sourceSheet:'X',sourceHeader:'Effective Fraction (%)',sourceColumnIndex:0,method:'manual'};
const mapText={sourceSheet:'X',sourceHeader:'Name',sourceColumnIndex:0,method:'manual'};
const mapDate={sourceSheet:'X',sourceHeader:'Date',sourceColumnIndex:0,method:'manual'};
check('UNIT_CONVERT_CM_TO_M',canonicalizeValue(10000,decimalField,mapCm,config.canonicalizationPolicy).canonicalValue,100);
check('UNIT_CONVERT_STATUS',canonicalizeValue(10000,decimalField,mapCm,config.canonicalizationPolicy).status,'converted');
check('FRACTION_PERCENT_TO_RATIO',canonicalizeValue(80,fractionField,mapPct,config.canonicalizationPolicy).canonicalValue,0.8);
check('UNSUPPORTED_EXPLICIT_UNIT_STATUS',canonicalizeValue(10,decimalField,mapYd,config.canonicalizationPolicy).status,'unit-error');
check('UNSUPPORTED_EXPLICIT_UNIT_NULL',canonicalizeValue(10,decimalField,mapYd,config.canonicalizationPolicy).canonicalValue,null);
check('TEXT_TRIM_OUTER',canonicalizeValue('  Demo Project  ',textField,mapText,config.canonicalizationPolicy).canonicalValue,'Demo Project');
check('TEXT_INTERNAL_WHITESPACE_PRESERVED',canonicalizeValue('Demo   Project',textField,mapText,config.canonicalizationPolicy).canonicalValue,'Demo   Project');
check('NUMERIC_STRING_COMMAS',parseNumber('1,23,456.75',config.canonicalizationPolicy).value,123456.75);
check('NUMERIC_STRING_ZERO',canonicalizeValue('0',decimalField,{...mapCm,sourceHeader:'Length'},config.canonicalizationPolicy).canonicalValue,0);
check('AMBIGUOUS_DATE_REJECTED',parseDate('03/04/2025').ok,false);
check('ISO_DATE_ACCEPTED',parseDate('2025-03-31').value,'2025-03-31');
check('INVALID_CALENDAR_DATE_REJECTED',parseDate('2025-02-29').ok,false);

// Engine 3 diagnostic is non-destructive and deferred to Engine 4.
const customRaw={...non.store.getState().raw,sheets:structuredClone(non.store.getState().raw.sheets)};
customRaw.sheets.find(s=>s.name==='01_Control').records[0].values[4]='03/04/2024';
const built=buildCanonicalTables({raw:customRaw,mapping:non.mapping,inputSchema:config.inputSchema,policy:config.canonicalizationPolicy});
check('DIAGNOSTIC_DATE_TYPE_ERROR',built.diagnostics[0].code,'DATE_TYPE_ERROR');
check('DIAGNOSTIC_CANONICAL_NULL',built.tables.find(t=>t.expectedSheet==='01_Control').records[0].values['CTL-005'],null);
check('DIAGNOSTIC_SOURCE_PRESERVED',built.tables.find(t=>t.expectedSheet==='01_Control').records[0].cells['CTL-005'].sourceValue,'03/04/2024');

// Engine boundary: unfinalized mapping must not canonicalize.
let blocked=false;
try{
  const st=createStore(),b=createEventBus();
  await runEngine01({file:await fileFrom('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','x.xlsx'),config},{store:st,bus:b});
  await runEngine02({config},{store:st,bus:b});
  await runEngine03({config},{store:st,bus:b});
}catch(e){blocked=/mapping is finalized|mapping.*finalized/i.test(e.message)}
check('UNFINALIZED_MAPPING_BLOCKED',blocked,true);

// Store invalidation graph clears canonical truth when mapping changes.
const inv=createStore();
inv.patch({mapping:{x:1},canonicalization:{x:1},canonical:{x:1}});
inv.patchFrom('mapping',{mapping:{x:2}});
check('MAPPING_INVALIDATES_CANONICAL_SUMMARY',inv.getState().canonicalization,null);
check('MAPPING_INVALIDATES_CANONICAL_PRIVATE',inv.getState().canonical,null);

const failed=checks.filter(c=>c.status==='FAIL');
const result={status:failed.length?'FAIL':'PASS',checks,failedCount:failed.length};
await fs.writeFile(new URL('tests/node-engine03-result.json',root),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
process.exitCode=failed.length?1:0;

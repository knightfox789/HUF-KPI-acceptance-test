import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03 } from '../js/engines/engine03-canonicalization.js';
import { runEngine04 } from '../js/engines/engine04-validation.js';
const require=createRequire(import.meta.url);globalThis.JSZip=require('jszip');globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),mappingAliases:await json('config/mapping-aliases-v1.1.json'),canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json'),validationRulebook:await json('config/validation-rulebook-v1.0.json'),routeRegistry:await json('config/route-registry-v1.1.json')};
async function fileFrom(path){const b=await fs.readFile(new URL(path,root));return new File([b],path.split('/').pop(),{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path),config},{store,bus});const m=await finalizeMapping(await runEngine02({config},{store,bus}));store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:m,error:null});await runEngine03({config},{store,bus});const summary=await runEngine04({config},{store,bus});return summary;}
const cases=[
 ['FX_HR_001_Missing_Leap_Day.xlsx','VAL-049','SERIES_BLOCK',11,0],
 ['FX_HR_002_Duplicate_Rainfall_Date.xlsx','VAL-045','SERIES_BLOCK',10,0],
 ['FX_HR_003_Negative_Rainfall.xlsx','VAL-047','SERIES_BLOCK',10,0],
 ['FX_HR_004_Missing_Verified_Base_Area.xlsx','VAL-055','RECORD_BLOCK',1,0],
 ['FX_HR_005_Base_Area_Exceeds_Surface.xlsx','VAL-056','RECORD_BLOCK',1,0],
 ['FX_HR_006_Missing_Feb_Evaporation.xlsx','VAL-059','RECORD_BLOCK',11,0],
 ['FX_HR_007_Advanced_Stage_Missing_Group.xlsx','VAL-019','RECORD_BLOCK',1,0],
 ['FX_HR_008_Cascade_Cycle.xlsx','VAL-043','NETWORK_BLOCK',2,0],
 ['FX_HR_009_REJ_A_Missing_Baseline.xlsx','VAL-033','RECORD_BLOCK',1,0],
 ['FX_HR_010_REJ_B_Missing_Desilted.xlsx','VAL-034','RECORD_BLOCK',1,0],
 ['FX_HR_011_Lined_Pond_Inlet_Fail.xlsx','VAL-073','RECORD_BLOCK',1,0],
 ['FX_HR_012_Other_Surface_Approval_Missing.xlsx','VAL-031','RECORD_BLOCK',1,0],
 ['FX_HR_013_Person_Day_Duplicate.xlsx','VAL-082','RECORD_BLOCK',0,2],
 ['FX_HR_014_Rainfall_Outside_FY.xlsx','VAL-050','WARNING_ONLY',0,0],
 ['FX_HR_015_Partial_Season_Missing_Functional_Date.xlsx','VAL-026','RECORD_BLOCK',1,0],
];
const results=[];
for(const [file,rule,scope,expectedWaterBlocked,expectedPdBlocked] of cases){
 const s=await run(`tests/fixtures/engine04/${file}`);const matches=s.issuePreview.filter(i=>i.ruleId===rule);
 const targetOk=matches.length>0;const scopeOk=matches.some(i=>i.scopeEffect===scope);
 const waterBlocked=s.structureReadiness.filter(x=>['not_ready','workbook_not_ready'].includes(x.validationReadiness)).length;
 const pdBlocked=s.personDayReadiness.filter(x=>x.validationReadiness==='not_ready').length;
 const independenceOk=waterBlocked===expectedWaterBlocked&&pdBlocked===expectedPdBlocked;
 results.push({file,rule,scope,targetOk,scopeOk,waterBlocked,expectedWaterBlocked,pdBlocked,expectedPdBlocked,independenceOk,status:targetOk&&scopeOk&&independenceOk?'PASS':'FAIL',issues:s.issuePreview.map(i=>i.ruleId)});
 console.log(JSON.stringify(results.at(-1)));
}
const failed=results.filter(x=>x.status==='FAIL');const out={status:failed.length?'FAIL':'PASS',cases:results,failedCount:failed.length};await fs.writeFile(new URL('tests/node-engine04-fixtures-result.json',root),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));process.exitCode=failed.length?1:0;

import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, buildMappingPreview, confirmAllSuggested, finalizeMapping, updateFieldMapping, updateSheetMapping, confirmSheetMapping } from '../js/engines/engine02-mapping.js';

const require=createRequire(import.meta.url);
globalThis.JSZip=require('jszip');
globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);
const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={
 app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),
 inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),
 mappingAliases:await json('config/mapping-aliases-v1.1.json')
};
const checks=[]; const check=(id,a,e)=>checks.push({id,actual:a,expected:e,status:Object.is(a,e)?'PASS':'FAIL'});
async function fileFrom(path,name){const b=await fs.readFile(new URL(path,root));return new File([b],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path,name){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path,name),config},{store,bus});const map=await runEngine02({config},{store,bus});return {store,map};}

const non=await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');
check('E02_STATUS',non.map.status,'mapping_review');
check('EXPECTED_FIELDS',non.map.stats.expectedFields,147);
check('MAPPED_FIELDS',non.map.stats.mappedFields,147);
check('UNMAPPED_FIELDS',non.map.stats.unmappedFields,0);
check('CONFIRMATION_REQUIRED_EXACT_TEMPLATE',non.map.stats.confirmationRequired,0);
check('CONFLICTS_EXACT_TEMPLATE',non.map.stats.conflicts,0);
check('NORMALIZED_HEADER_METHOD_COUNT',non.map.stats.methods['normalized-header'],147);
check('SOURCE_CATALOG_SHEETS',non.map.sourceCatalog.length,13);
check('RAW_SOURCE_STILL_FROZEN',Object.isFrozen(non.store.getState().raw.sheets),true);
check('PUBLIC_STATE_HAS_NO_RAW',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'raw'),false);
const frozen=await finalizeMapping(non.map);
check('FINAL_STATUS',frozen.status,'mapping_confirmed');
check('MAPPING_HASH_LENGTH',frozen.snapshotHash.length,64);
check('IMMUTABLE_MAPPING_SNAPSHOT',Object.isFrozen(frozen.immutableSnapshot),true);

// Alias mutation on a deep clone of raw headers only: CTL-002 Project ID -> Project Code.
const aliasRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
const ctl=aliasRaw.sheets.find(s=>s.name==='01_Control');
ctl.headers[1]='Project Code';
const aliasPreview=buildMappingPreview({raw:aliasRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
const aliasMap=aliasPreview.fieldMappings.find(m=>m.fieldId==='CTL-002');
check('ALIAS_METHOD',aliasMap.method,'alias');
check('ALIAS_NEEDS_CONFIRMATION',aliasMap.needsConfirmation,true);
check('ALIAS_SOURCE_HEADER',aliasMap.sourceHeader,'Project Code');
const aliasWrapper={engine:'E02',sourceSessionId:'test',sourceWorkbookSha256:'abc',schemaVersion:config.inputSchema.schema_version,sourceCatalog:[],...aliasPreview,status:'mapping_review',snapshotHash:null};
const aliasConfirmed=confirmAllSuggested(aliasWrapper);
check('ALIAS_CONFIRM_ALL_CLEARS_PENDING',aliasConfirmed.stats.confirmationRequired,0);

// Fuzzy typo for Verified Base Area.
const fuzzyRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
const tech=fuzzyRaw.sheets.find(s=>s.name==='03_Technical'); tech.headers[20]='Verified Base Aera';
const fuzzyPreview=buildMappingPreview({raw:fuzzyRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
const fuzzyMap=fuzzyPreview.fieldMappings.find(m=>m.fieldId==='TEC-021');
check('FUZZY_METHOD',fuzzyMap.method,'fuzzy');
check('FUZZY_NEEDS_CONFIRMATION',fuzzyMap.needsConfirmation,true);
check('FUZZY_SOURCE_HEADER',fuzzyMap.sourceHeader,'Verified Base Aera');

// Manual remap restores a deliberately unmapped field.
const manualRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
const mctl=manualRaw.sheets.find(s=>s.name==='01_Control'); mctl.headers[2]='Completely Unknown Header';
const manualPreview=buildMappingPreview({raw:manualRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
const baseMapping={engine:'E02',sourceSessionId:'test',sourceWorkbookSha256:'abc',schemaVersion:config.inputSchema.schema_version,sourceCatalog:manualRaw.sheets.map(s=>({name:s.name,headers:s.headers.map((h,index)=>({header:h,index}))})),...manualPreview,status:'mapping_review',snapshotHash:null};
const before=baseMapping.fieldMappings.find(m=>m.fieldId==='CTL-003');
check('UNKNOWN_HEADER_UNMAPPED',before.method,'unmapped');
const after=updateFieldMapping(baseMapping,manualRaw,'CTL-003','01_Control',2).fieldMappings.find(m=>m.fieldId==='CTL-003');
check('MANUAL_METHOD',after.method,'manual');
check('MANUAL_CONFIRMED',after.confirmed,true);


// Exact field-ID header takes precedence.
const idRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
idRaw.sheets.find(s=>s.name==='01_Control').headers[1]='CTL-002';
const idPreview=buildMappingPreview({raw:idRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
const idMap=idPreview.fieldMappings.find(m=>m.fieldId==='CTL-002');
check('EXACT_FIELD_ID_METHOD',idMap.method,'exact-field-id');
check('EXACT_FIELD_ID_AUTO_CONFIRMED',idMap.confirmed,true);

// Sheet alias requires explicit confirmation, and confirming it clears the sheet-level pending count.
const sheetRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
sheetRaw.sheets.find(s=>s.name==='01_Control').name='Control';
const sheetPreview=buildMappingPreview({raw:sheetRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
const sheetMap=sheetPreview.sheetMappings.find(m=>m.expectedSheet==='01_Control');
check('SHEET_ALIAS_METHOD',sheetMap.method,'sheet-alias');
check('SHEET_ALIAS_CONFIRM_REQUIRED',sheetPreview.stats.sheetConfirmationRequired,1);
let sheetWrapper={engine:'E02',sourceSessionId:'test',sourceWorkbookSha256:'abc',schemaVersion:config.inputSchema.schema_version,sourceCatalog:sheetRaw.sheets.map(s=>({name:s.name,headers:s.headers.map((h,index)=>({header:h,index}))})),...sheetPreview,status:'mapping_review',snapshotHash:null};
sheetWrapper=confirmSheetMapping(sheetWrapper,'01_Control',true);
check('SHEET_CONFIRM_CLEARS_PENDING',sheetWrapper.stats.sheetConfirmationRequired,0);

// Manual sheet remap rebuilds field mappings against the selected sheet.
const manualSheetRaw={sheets:structuredClone(non.store.getState().raw.sheets)};
manualSheetRaw.sheets.find(s=>s.name==='01_Control').name='Mystery Control Sheet';
const manualSheetPreview=buildMappingPreview({raw:manualSheetRaw,inputSchema:config.inputSchema,aliases:config.mappingAliases});
let manualSheetWrapper={engine:'E02',sourceSessionId:'test',sourceWorkbookSha256:'abc',schemaVersion:config.inputSchema.schema_version,sourceCatalog:manualSheetRaw.sheets.map(s=>({name:s.name,headers:s.headers.map((h,index)=>({header:h,index}))})),...manualSheetPreview,status:'mapping_review',snapshotHash:null};
manualSheetWrapper=updateSheetMapping(manualSheetWrapper,manualSheetRaw,config.inputSchema,config.mappingAliases,'01_Control','Mystery Control Sheet');
check('MANUAL_SHEET_METHOD',manualSheetWrapper.sheetMappings.find(m=>m.expectedSheet==='01_Control').method,'manual-sheet');
check('MANUAL_SHEET_REMAPS_FIELDS',manualSheetWrapper.fieldMappings.filter(m=>m.expectedSheet==='01_Control'&&m.sourceHeader!==null).length,16);

// Same mapping content produces same deterministic hash.
const frozen2=await finalizeMapping(non.map);
check('DETERMINISTIC_MAPPING_HASH',frozen2.snapshotHash,frozen.snapshotHash);

// An unmapped field is preserved as unmapped/null and finalizes with an explicit status, not a fake zero/default.
const unmappedFinal=await finalizeMapping(baseMapping);
check('FINAL_WITH_UNMAPPED_STATUS',unmappedFinal.status,'mapping_confirmed_with_unmapped');
check('FINAL_WITH_UNMAPPED_COUNT',unmappedFinal.stats.unmappedFields,1);

// Deliberate duplicate source-column assignment creates a conflict and blocks finalization.
let conflictMapping=updateFieldMapping(non.map,non.store.getState().raw,'CTL-003','01_Control',1);
check('CONFLICT_DETECTED',conflictMapping.stats.conflicts,2);
let conflictBlocked=false;try{await finalizeMapping(conflictMapping);}catch(e){conflictBlocked=/conflict/i.test(e.message)}
check('CONFLICT_BLOCKS_FINALIZE',conflictBlocked,true);

const failed=checks.filter(c=>c.status==='FAIL');
const result={status:failed.length?'FAIL':'PASS',checks,failedCount:failed.length};
await fs.writeFile(new URL('tests/node-engine02-result.json',root),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
process.exitCode=failed.length?1:0;

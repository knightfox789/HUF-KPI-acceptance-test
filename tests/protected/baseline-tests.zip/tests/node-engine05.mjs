import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createStore } from '../js/core/store.js';
import { createEventBus } from '../js/core/events.js';
import { runEngine01 } from '../js/engines/engine01-intake.js';
import { runEngine02, finalizeMapping } from '../js/engines/engine02-mapping.js';
import { runEngine03 } from '../js/engines/engine03-canonicalization.js';
import { runEngine04 } from '../js/engines/engine04-validation.js';
import { runEngine05, resolveOfficialWaterRoute, resolvePersonDayRoute } from '../js/engines/engine05-routing.js';

const require=createRequire(import.meta.url);globalThis.JSZip=require('jszip');globalThis.DOMParser=require('@xmldom/xmldom').DOMParser;
const root=new URL('../',import.meta.url);const json=async p=>JSON.parse(await fs.readFile(new URL(p,root),'utf8'));
const config={app:await json('config/app-config.json'),sheetContract:await json('config/required-sheets-v1.1.json'),inputSchema:await json('config/input-schema-v1.1.json'),engineContracts:await json('config/engine-contracts-v1.json'),mappingAliases:await json('config/mapping-aliases-v1.1.json'),canonicalizationPolicy:await json('config/canonicalization-policy-v1.1.json'),validationRulebook:await json('config/validation-rulebook-v1.0.json'),routeRegistry:await json('config/route-registry-v1.1.json'),routingPolicy:await json('config/routing-policy-v1.0.json')};
const checks=[];const check=(id,a,e)=>checks.push({id,actual:a,expected:e,status:Object.is(a,e)?'PASS':'FAIL'});const truec=(id,a)=>check(id,Boolean(a),true);
async function fileFrom(path,name){const b=await fs.readFile(new URL(path,root));return new File([b],name,{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
async function run(path,name){const store=createStore(),bus=createEventBus();await runEngine01({file:await fileFrom(path,name),config},{store,bus});const m=await finalizeMapping(await runEngine02({config},{store,bus}));store.patchFrom('mapping',{lifecycle:'mapping_confirmed',mapping:m,error:null});await runEngine03({config},{store,bus});await runEngine04({config},{store,bus});const summary=await runEngine05({config},{store,bus});return {store,summary,private:store.getState().routed.immutableSnapshot};}

const non=await run('tests/fixtures/GOLDEN_E2E_NONLEAP_FY2024-25.xlsx','nonleap.xlsx');
const leap=await run('tests/fixtures/GOLDEN_E2E_LEAP_FY2023-24.xlsx','leap.xlsx');
const expectedRoutes={'WTR-111-NEW':9,'WTR-111-REJ-A':1,'WTR-111-REJ-B':1,'WTR-112-NEW':3,'WTR-112-REJ-A':1,'WTR-112-REJ-B':1,'WTR-LFP':1,'WTR-HOLD-PARTLY-LINED':1,'WTR-EXCL-GOV':1,'WTR-EXCL-SUB':1};
const expectedPd={'PD-DIRECT':5,'PD-COMMUNITY':5,'PD-VOLUME':5,'PD-MACHINERY':5};
check('E05_ENGINE',non.summary.engine,'E05');
check('E05_LIFECYCLE',non.store.getState().lifecycle,'routing_ready');
check('ROUTING_STATUS',non.summary.status,'routing_ready');
check('WATER_DECISIONS',non.summary.stats.waterRouteDecisions,20);
check('WATER_ASSIGNED',non.summary.stats.assignedWaterRoutes,20);
check('WATER_UNRESOLVED',non.summary.stats.unresolvedWaterRoutes,0);
check('PD_ASSIGNED',non.summary.stats.assignedPersonDayRoutes,20);
check('PD_UNRESOLVED',non.summary.stats.unresolvedPersonDayRoutes,0);
for(const [id,count] of Object.entries(expectedRoutes))check(`ROUTE_${id}`,non.summary.stats.routeCounts[id],count);
for(const [id,count] of Object.entries(expectedPd))check(`PD_${id}`,non.summary.stats.pdRouteCounts[id],count);
check('EXACTLY_ONE_PER_STRUCTURE',new Set(non.summary.waterRoutes.map(x=>x.structureRecordId)).size,20);
check('OFFICIAL_ROUTE_ENUMS_VALID',non.summary.waterRoutes.filter(x=>!config.routeRegistry.water_routes.some(r=>r.route_id===x.waterRouteId)).length,0);
check('CANDIDATE_MATCH_GOLDEN',non.summary.waterRoutes.filter(x=>non.store.getState().validation.structureReadiness.find(v=>v.structureRecordId===x.structureRecordId)?.candidateRouteHint!==x.waterRouteId).length,0);
check('PARTLY_OFFICIAL_HOLD',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-FP-P-01').waterRouteId,'WTR-HOLD-PARTLY-LINED');
check('PARTLY_ELIGIBILITY',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-FP-P-01').eligibilityStatus,'hold');
check('GOV_OFFICIAL_EXCL',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-GOV-01').waterRouteId,'WTR-EXCL-GOV');
check('SUB_OFFICIAL_EXCL',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-SUB-01').waterRouteId,'WTR-EXCL-SUB');
check('LFP_ROUTE',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-FP-L-01').waterRouteId,'WTR-LFP');
check('MW_PARTIAL_ROUTE',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-MW-01').waterRouteId,'WTR-111-NEW');
check('MW_SIM_START',non.summary.waterRoutes.find(x=>x.structureRecordId==='S-MW-01').simulationStartDate,'2024-07-20');
check('LEGACY_READY_WARNING_COUNT',non.summary.waterRoutes.filter(x=>x.eligibilityStatus==='eligible_with_warning').length,11);
check('ELIGIBLE_COUNT',non.summary.waterRoutes.filter(x=>x.eligibilityStatus==='eligible').length,6);
check('HOLD_COUNT',non.summary.waterRoutes.filter(x=>x.eligibilityStatus==='hold').length,1);
check('EXCLUDED_COUNT',non.summary.waterRoutes.filter(x=>x.eligibilityStatus==='excluded').length,2);
check('PD_INDEPENDENT_ALL',non.summary.personDayRoutes.filter(x=>x.independentFromWater).length,20);
check('PRIVATE_ROUTING_FROZEN',Object.isFrozen(non.private),true);
check('PUBLIC_STATE_NO_PRIVATE_ROUTED',Object.prototype.hasOwnProperty.call(non.store.getPublicState(),'routed'),false);
check('ROUTING_HASH_LENGTH',non.summary.routingSnapshotHash.length,64);
check('CONTENT_HASH_LENGTH',non.summary.routingContentHash.length,64);
check('ROUTE_REGISTRY_VERSION',non.summary.routeRegistryVersion,'HUF-DESIGN1-ROUTE-REGISTRY-v1.1');
check('ROUTING_POLICY_VERSION',non.summary.routingPolicyVersion,'HUF-E05-OFFICIAL-ROUTING-v1.0');
check('LEAP_SAME_ROUTE_COUNTS',JSON.stringify(leap.summary.stats.routeCounts),JSON.stringify(non.summary.stats.routeCounts));
check('LEAP_SAME_PD_COUNTS',JSON.stringify(leap.summary.stats.pdRouteCounts),JSON.stringify(non.summary.stats.pdRouteCounts));
truec('NO_NUMERIC_WATER_RESULT_FIELDS',non.summary.waterRoutes.every(x=>!Object.prototype.hasOwnProperty.call(x,'waterResultM3')));
truec('NO_CALCULATED_PERSON_DAYS_FIELDS',non.summary.personDayRoutes.every(x=>!Object.prototype.hasOwnProperty.call(x,'calculatedPersonDays')));

// Pure routing precedence / unresolved tests.
const mk=(v)=>({values:v});
const ctl=mk({'CTL-009':'Strict cutoff','CTL-008':'2024-06-30','CTL-005':'2024-04-01'});
check('PURE_NEW_BEFORE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Check Dam','STR-005':'New construction','STR-006':'Unlined','STR-007':'2024-06-01'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-111-NEW');
check('PURE_NEW_AFTER',resolveOfficialWaterRoute({structure:mk({'STR-003':'Check Dam','STR-005':'New construction','STR-006':'Unlined','STR-007':'2024-07-01'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-112-NEW');
check('PURE_REJA_BEFORE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Farm Bund','STR-005':'Rejuvenation/repair','STR-006':'Unlined','STR-007':'2024-05-01','STR-020':'Post-intervention minus baseline capacity'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-111-REJ-A');
check('PURE_REJB_AFTER',resolveOfficialWaterRoute({structure:mk({'STR-003':'Village Pond','STR-005':'Rejuvenation/repair','STR-006':'Unlined','STR-007':'2024-08-01','STR-020':'Verified desilted volume'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-112-REJ-B');
check('PURE_PARTIAL_AFTER',resolveOfficialWaterRoute({structure:mk({'STR-003':'Masonry Weir','STR-005':'New construction','STR-006':'Unlined','STR-007':'2024-07-01','STR-008':'2024-07-20','STR-019':'Actual functional date - partial season'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-111-NEW');
check('PURE_LFP_PRECEDENCE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Farm Pond','STR-005':'New construction','STR-006':'Fully lined','STR-007':'2024-07-01'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-LFP');
check('PURE_PARTLY_PRECEDENCE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Farm Pond','STR-005':'New construction','STR-006':'Partly lined','STR-007':'2024-05-01'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-HOLD-PARTLY-LINED');
check('PURE_GOV_PRECEDENCE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Village Pond','STR-005':'Governance-related','STR-006':'Not applicable'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-EXCL-GOV');
check('PURE_SUB_PRECEDENCE',resolveOfficialWaterRoute({structure:mk({'STR-003':'Subsurface recharge structure - excluded unless approved','STR-005':'New construction','STR-006':'Not applicable'}),control:ctl,routeRegistry:config.routeRegistry}).waterRouteId,'WTR-EXCL-SUB');
check('PURE_MISSING_COMPLETION',resolveOfficialWaterRoute({structure:mk({'STR-003':'Check Dam','STR-005':'New construction','STR-006':'Unlined'}),control:ctl,routeRegistry:config.routeRegistry}).decisionStatus,'unresolved');
check('PURE_MISSING_REJ_METHOD',resolveOfficialWaterRoute({structure:mk({'STR-003':'Farm Bund','STR-005':'Rejuvenation/repair','STR-006':'Unlined','STR-007':'2024-05-01'}),control:ctl,routeRegistry:config.routeRegistry}).decisionStatus,'unresolved');
check('PURE_WORKBOOK_WITHHOLD',resolveOfficialWaterRoute({structure:mk({'STR-003':'Check Dam','STR-005':'New construction','STR-006':'Unlined','STR-007':'2024-05-01'}),control:ctl,routeRegistry:config.routeRegistry,workbookReadiness:'workbook_not_ready'}).decisionStatus,'withheld_workbook_not_ready');
for(const [cat,id] of [['Paid labour','PD-DIRECT'],['Community contribution','PD-COMMUNITY'],['Volume-based estimate','PD-VOLUME'],['Machinery-support labour','PD-MACHINERY']])check(`PURE_PD_${id}`,resolvePersonDayRoute(cat,config.routingPolicy).personDayRouteId,id);
check('PURE_PD_UNKNOWN',resolvePersonDayRoute('Unknown',config.routingPolicy).decisionStatus,'unresolved');

const failed=checks.filter(c=>c.status==='FAIL');const result={status:failed.length?'FAIL':'PASS',checks,failedCount:failed.length,nonleapStats:non.summary.stats,leapStats:leap.summary.stats};
await fs.writeFile(new URL('tests/node-engine05-result.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=failed.length?1:0;
